public class Pills extends Medicine {
    private int numOfPillsInBox;

    // Override the total inventory method
    @Override
    public double totalInventory() {
        return quantity * numOfPillsInBox;
    }

    // constructors
    public Pills() {
    }

    public Pills(String medicineName, String companyName, String companyEmail, double price, int quantity, int expirationYear, int numOfPillsInBox) throws InvalidEmailAddressException {
        super(medicineName, companyName, companyEmail, price, quantity, expirationYear, MedicineType.PILLS);
        setNumOfPillsInBox(numOfPillsInBox);
    }

    // setter

    public void setNumOfPillsInBox(int numOfPillsInBox) {
        this.numOfPillsInBox = numOfPillsInBox;
    }

    // getter
    public int getNumOfPillsInBox() {
        return numOfPillsInBox;
    }

    // print method
    @Override
    public String toString() {
        return super.toString() + " number of pills in a box= " + numOfPillsInBox;
    }


}
