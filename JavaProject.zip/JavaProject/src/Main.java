import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Creating an inventory

        Inventory inventory = new Inventory();

        // Creating 3 new medicines of each type

        Syrup s1 = null, s2 = null, s3 = null;
        Pills p1 = null, p2 = null, p3 = null;
        Inhaler i1 = null, i2 = null, i3 = null;
        try {
            s1 = new Syrup("Acamol", "Teva", "Teva@org.il", 19.9,
                    200, 2025, 2000);
            s2 = new Syrup("Nurofen", "Teva", "Teva@org.il", 26.5,
                    180, 2026, 250);
            s3 = new Syrup("Fenistil", "Cts", "cts@org.il", 18.9,
                    90, 2030, 60);
            p1 = new Pills("Zinat", "Taro", "Taro@comp.co.il", 15.9,
                    30, 2030, 18);
            p2 = new Pills("Ogmentin", "Teva", "Teva@org.il", 20,
                    50, 2030, 24);
            p3 = new Pills("optalgin", "Health", "hlt@gmail.com", 25.9,
                    200, 2028, 50);
            i1 = new Inhaler("Arovent", "Cts", "cts@org.il", 18,
                    70, 2028, 170);
            i2 = new Inhaler("Ventolin", "Cts", "cts@org.il", 20.9,
                    50, 2026, 100);
            i3 = new Inhaler("Budicort", "Teva", "Teva@orgil", 18.9, 30, 2027, 50);
        } catch (InvalidEmailAddressException e) {
            e.printStackTrace();
        }
        // Adding the medicine to the inventory.

        try {
            inventory.addMedicine(s1);
            inventory.addMedicine(s2);
            inventory.addMedicine(s3);
            inventory.addMedicine(p1);
            inventory.addMedicine(p2);
            inventory.addMedicine(p3);
            inventory.addMedicine(i1);
            inventory.addMedicine(i2);
        } catch (MedicineAlreadyExistException e) {
            e.printStackTrace();
        }
        System.out.println("**************************");

        // Searching for a specific medicine by name

        try {
            Medicine medicine = inventory.searchMedicineByName("Acamol");
            System.out.println(medicine.getMedicineName() + medicine.totalInventory());

        } catch (MedicineDoesNotExistException e) {
            e.printStackTrace();
        }

        System.out.println("**************************");

        // Searching for all medicine by type (Pills)

        ArrayList<Medicine> allPills = inventory.searchMedicineByType(Medicine.MedicineType.PILLS);
        System.out.println("Searching for all medicine by type (Pills)");
        for (Medicine medicine : allPills) {
            System.out.println(medicine.toString());
        }
        System.out.println("**************************");

        // Printing all medicine in stock

        ArrayList<Medicine> allInStock = inventory.getMedicineInStock();
        System.out.println("Printing all medicine in stock");
        for (Medicine medicine : allInStock) {
            System.out.println(medicine.toString());
        }
        System.out.println("**************************");

        // Trying to add a medicine that exists in the inventory
        try {
            inventory.addMedicine(s1);
        } catch (MedicineAlreadyExistException e) {
            e.printStackTrace();
        }
        System.out.println("**************************");

        // Searching for a non-existing medicine
        try {
            Medicine medicine = inventory.searchMedicineByName("Vitamin B12");
        } catch (MedicineDoesNotExistException e) {
            e.printStackTrace();
        }
//        // Trying to add a medicine with an incorrect email
        try {
            inventory.addMedicine(new Pills("abc", "bbb", "@nnn@dd.com", 19.9, 56, 2024, 100));

        } catch (MedicineAlreadyExistException e) {
            e.printStackTrace();
        } catch (InvalidEmailAddressException e) {
            e.printStackTrace();
        }


    }


}