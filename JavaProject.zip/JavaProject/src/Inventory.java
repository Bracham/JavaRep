import java.net.Proxy;
import java.util.ArrayList;

// Class contains array list of all medicines
public class Inventory {
    ArrayList<Medicine> medicineArrayList = new ArrayList<>();

    // Function which adds a new medicine to the Array list.
    // Before adding a new medicine to the inventory, checks if medicine name already exists.
    public void addMedicine(Medicine newMedicine) throws MedicineAlreadyExistException {
        for (Medicine singalMedicine : medicineArrayList) {
            if (singalMedicine.getMedicineName().equalsIgnoreCase(newMedicine.getMedicineName())) {
                throw new MedicineAlreadyExistException(newMedicine);
            }
        }
        medicineArrayList.add(newMedicine);
    }

    // Function that returns a medicine according to its name, and prints its total inventory.
    public Medicine searchMedicineByName(String name) throws MedicineDoesNotExistException {
        for (Medicine medicine : medicineArrayList) {

            if (name.equalsIgnoreCase(medicine.getMedicineName()))
                return medicine;

        }
        throw new MedicineDoesNotExistException(name);
    }


    // Function that returns an array list of medicines by type.
    public ArrayList<Medicine> searchMedicineByType(Medicine.MedicineType type) {
        ArrayList<Medicine> subArr = new ArrayList<>();
        for (Medicine medicine : medicineArrayList) {
            if (medicine.getType().equals(type))
                subArr.add(medicine);
        }
        return subArr;
    }

    // Returns array list of all medicines in stock.
    public ArrayList<Medicine> getMedicineInStock() {
        ArrayList<Medicine> subArr = new ArrayList<>();
        for (Medicine medicine : medicineArrayList) {
            if (medicine.getQuantity() > 0)
                subArr.add(medicine);
        }
        return subArr;
    }

        }










