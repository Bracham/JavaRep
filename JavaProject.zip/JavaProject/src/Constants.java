public class Constants {
   public static final String STRUDEL= "@";
    public static final String DOT= ".";
}

