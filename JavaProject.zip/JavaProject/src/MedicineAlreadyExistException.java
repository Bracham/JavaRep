// An exception, for a medicine that already exists and there for was not added to the inventory, with an error message
public class MedicineAlreadyExistException extends Exception{
    public MedicineAlreadyExistException (Medicine medicineName) {
        super("The medicine "+ medicineName+ " already exists in the inventory");

    }
}
