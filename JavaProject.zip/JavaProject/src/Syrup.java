public class Syrup extends Medicine {
    private double bottleContent;

    // Override the total inventory method
    @Override
    public double totalInventory() {
        return quantity * bottleContent;
    }

    // constructors
    public Syrup() {
    }

    public Syrup(String medicineName, String companyName, String companyEmail, double price, int quantity,
                 int expirationYear, double bottleContent) throws InvalidEmailAddressException {
        super(medicineName, companyName, companyEmail, price, quantity, expirationYear, MedicineType.SYRUP);
        setBottleContent(bottleContent);
    }

    // setter

    public void setBottleContent(double bottleContent) {
        this.bottleContent = bottleContent;
    }

    // getter
    public double getBottleContent() {
        return bottleContent;
    }

    // print method
    @Override
    public String toString() {
        return super.toString() + "number of bottles= " + quantity + " bottle content= " + bottleContent;
    }
}
