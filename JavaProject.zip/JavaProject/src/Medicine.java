import java.lang.reflect.Type;

// An abstract class.
public abstract class Medicine {

    // Attributes
    private String medicineName;
    private String companyName;
    private String companyEmail;
    private double price;
    protected double quantity;
    private int expirationYear;
    private MedicineType type;

    // Type, which is an enum
    public enum MedicineType {
        PILLS,
        SYRUP,
        INHALER
    }

    // constructors
    public Medicine() {
    }

    public Medicine(String medicineName, String companyName, String companyEmail, double price,
                    int quantity, int expirationYear, MedicineType type) throws InvalidEmailAddressException {
        setMedicineName(medicineName);
        setCompanyName(companyName);
        setCompanyEmail(companyEmail);
        setPrice(price);
        setQuantity(quantity);
        setExpirationYear(expirationYear);
        setType(type);
    }

    // setters
    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName.toUpperCase();
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setCompanyEmail(String companyEmail) throws InvalidEmailAddressException {
        if (isCompanyEmailValid(companyEmail))
            this.companyEmail = companyEmail;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public void setExpirationYear(int expirationYear) {
        this.expirationYear = expirationYear;
    }

    private void setType(MedicineType type) {
        this.type = type;
    }

    // getters

    public String getMedicineName() {
        return medicineName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getCompanyEmail() {
        return companyEmail;
    }

    public double getPrice() {
        return price;
    }

    public double getQuantity() {
        return quantity;
    }

    public int getExpirationYear() {
        return expirationYear;
    }

    public MedicineType getType() {
        return type;
    }

    // An abstract method to calculate the total inventory for each medicine type

    public abstract double totalInventory();

    // Method that returns true if quantity > 0, else returns false

    public boolean inStock() {
        return quantity > 0;
    }

    // A printing method
    public String toString() {
        return "medicine name= " + medicineName + " company name= " + companyName + " email of company= " + companyEmail +
                " price= " + price + " quantity= " + quantity + " expiration year= " + expirationYear + " type= " + type;
    }

    // method that checks if the company email is valid:
    // * The sign "strudel" and the sign "dot" appear at least once
    // * The sign "strudel" is not first or last char
    // * At least 1. (dot) character appears in the domain after the "strudel" sign

    public boolean isCompanyEmailValid(String email) throws InvalidEmailAddressException {
        if (!email.contains(Constants.STRUDEL) || email.contains(Constants.DOT))
            throw new InvalidEmailAddressException(email, "email must contain strudel and dot");
        if (!email.startsWith(Constants.STRUDEL) || !email.endsWith(Constants.STRUDEL))
            throw new InvalidEmailAddressException(email, "email cannot start or end with strudel");
        if (email.lastIndexOf(Constants.DOT) > email.indexOf(Constants.STRUDEL))
            throw new InvalidEmailAddressException(email, "The dot must be after the strudel");
        return true;
    }
}

