// An exception, for medicine that does not exist, with an error message
public class MedicineDoesNotExistException extends Exception {
    public MedicineDoesNotExistException(String name) {
        super("The " + name + " medicine does not exist in inventory");
    }
}
