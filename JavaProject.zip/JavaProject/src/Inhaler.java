public class Inhaler extends Medicine {

    private int amountOfClicks;

    // Override the total inventory method
    @Override
    public double totalInventory() {
        return quantity * amountOfClicks;
    }

    // constructors

    public Inhaler() {
    }

    public Inhaler(String medicineName, String companyName, String companyEmail, double price,
                   int quantity, int expirationYear, int amountOfClicks) throws InvalidEmailAddressException {
        super(medicineName, companyName, companyEmail, price, quantity, expirationYear, MedicineType.INHALER);
        setAmountOfClicks(amountOfClicks);
    }
    // setter

    public void setAmountOfClicks(int amountOfClicks) {
        this.amountOfClicks = amountOfClicks;
    }

    // getter
    public int getAmountOfClicks() {
        return amountOfClicks;
    }


    // print method
    @Override
    public String toString() {

        return super.toString() + "number of inhalers= " + quantity + "number of clicks in each inhaler= " + amountOfClicks;
    }
}

