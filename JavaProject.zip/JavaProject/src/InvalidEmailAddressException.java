
// An exception, for invalid email address, with an appropriate error message
public class InvalidEmailAddressException extends Exception {
    public InvalidEmailAddressException(String companyEmail, String message) {
        super("The email address " + companyEmail + " is invalid " + message);
    }

}
